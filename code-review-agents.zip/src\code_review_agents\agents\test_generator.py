"""Agent 5: 测试生成器 — 为变更和修复生成回归测试."""

from __future__ import annotations

from code_review_agents.agents.base import BaseAgent
from code_review_agents.prompts.templates import TEST_GENERATOR_PROMPT


class TestGeneratorAgent(BaseAgent):
    """根据 diff 变更和修复方案, 生成全面的回归测试用例."""

    MAX_TOKENS = 8192
    TEMPERATURE = 0.3

    def __init__(self) -> None:
        super().__init__(
            name="TestGenerator",
            system_prompt=TEST_GENERATOR_PROMPT,
            thinking_budget=4096,
        )

    async def generate_tests(
        self,
        diff_content: str,
        fixes: str,
        diff_analysis: str,
    ) -> str:
        """生成测试用例."""
        prompt = f"""\
## 原始变更
```diff
{diff_content[:3000]}
```

## Diff 分析
{diff_analysis[:2000]}

## 修复方案
{fixes[:3000]}

请生成全面的回归测试用例 (单元测试 + 集成测试 + E2E).
"""
        result = await self.run(prompt, phase="测试生成")
        return result.content
