"""Token 消耗统计器 — 跨阶段汇总与报告生成."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from code_review_agents.agents.base import TokenUsage


@dataclass
class PipelineTokenReport:
    """整个流水线的 token 消耗汇总."""

    stages: list[TokenUsage] = field(default_factory=list)
    total_input: int = 0
    total_output: int = 0
    total_cache_create: int = 0
    total_cache_read: int = 0
    total_duration_ms: float = 0.0

    @property
    def total_tokens(self) -> int:
        return self.total_input + self.total_output

    @property
    def estimated_cost_usd(self) -> float:
        return (self.total_input * 15 + self.total_output * 75) / 1_000_000

    def add_stage(self, usage: TokenUsage, stage_name: str) -> None:
        usage.phase = stage_name
        self.stages.append(usage)
        self.total_input += usage.input_tokens
        self.total_output += usage.output_tokens
        self.total_cache_create += usage.cache_create_tokens
        self.total_cache_read += usage.cache_read_tokens
        self.total_duration_ms += usage.duration_ms

    def format_summary(self) -> str:
        lines = [
            "╔══════════════════════════════════════════════════════════════════╗",
            "║              🔥 全流水线 Token 消耗统计报告                     ║",
            "╠══════════════════════════════════════════════════════════════════╣",
        ]
        for s in self.stages:
            lines.append(
                f"║ {s.phase:<20s} │ 输入: {s.input_tokens:>6d}  │ 输出: {s.output_tokens:>6d}  "
                f"│ 耗时: {s.duration_ms/1000:>5.1f}s ║"
            )
        lines.append("╠══════════════════════════════════════════════════════════════════╣")
        lines.append(
            f"║ {'总计':20s} │ 输入: {self.total_input:>6d}  │ 输出: {self.total_output:>6d}  "
            f"│ 耗时: {self.total_duration_ms/1000:>5.1f}s ║"
        )
        lines.append(
            f"║ {'缓存写入':20s} │ {self.total_cache_create:>6d} tokens                              ║"
        )
        lines.append(
            f"║ {'缓存读取':20s} │ {self.total_cache_read:>6d} tokens                              ║"
        )
        lines.append(
            f"║ {'预估成本(USD)':20s} │ ${self.estimated_cost_usd:.4f}                                      ║"
        )
        lines.append("╚══════════════════════════════════════════════════════════════════╝")
        return "\n".join(lines)
