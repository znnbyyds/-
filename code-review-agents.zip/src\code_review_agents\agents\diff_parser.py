"""Agent 1: Diff 解析器 — 将原始 PR diff 拆解为结构化审查单元."""

from __future__ import annotations

from code_review_agents.agents.base import BaseAgent
from code_review_agents.prompts.templates import DIFF_PARSER_PROMPT


class DiffParserAgent(BaseAgent):
    """解析 Git diff, 输出结构化的审查单元列表.

    作为流水线的入口 Agent, 负责:
    1. 统计变更规模和影响范围
    2. 按模块/风险拆分审查单元
    3. 生成依赖关系图
    4. 标注必须人工审查的关键代码
    """

    MAX_TOKENS = 4096
    TEMPERATURE = 0.2

    def __init__(self) -> None:
        super().__init__(
            name="DiffParser",
            system_prompt=DIFF_PARSER_PROMPT,
            thinking_budget=2048,
        )

    async def parse(self, diff_content: str) -> str:
        """解析 diff 内容, 返回结构化分析结果."""
        result = await self.run(
            user_content=f"请分析以下 PR diff:\n\n```diff\n{diff_content}\n```",
            phase="Diff 解析",
        )
        return result.content
