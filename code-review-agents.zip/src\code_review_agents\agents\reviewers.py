"""Agent 2: 四维并行审查员 — 逻辑/安全/性能/规范."""

from __future__ import annotations

import asyncio
from typing import Optional

from code_review_agents.agents.base import BaseAgent, AgentResult
from code_review_agents.prompts.templates import (
    LOGIC_REVIEWER_PROMPT,
    SECURITY_REVIEWER_PROMPT,
    PERFORMANCE_REVIEWER_PROMPT,
    STYLE_REVIEWER_PROMPT,
)


class ReviewerAgent(BaseAgent):
    """通用审查员 — 通过注入不同的 system_prompt 实现四维审查."""

    MAX_TOKENS = 4096
    TEMPERATURE = 0.3

    def __init__(self, dimension: str, prompt_template: str) -> None:
        self.dimension = dimension
        name_map = {
            "logic": "LogicReviewer",
            "security": "SecurityReviewer",
            "performance": "PerfReviewer",
            "style": "StyleReviewer",
        }
        super().__init__(
            name=name_map.get(dimension, f"Reviewer-{dimension}"),
            system_prompt=prompt_template,
            thinking_budget=2048,
        )

    async def review(self, diff_content: str, diff_analysis: str) -> AgentResult:
        prompt = f"""\
## PR Diff 原始内容
```diff
{diff_content[:4000]}
```

## Diff 结构化分析
{diff_analysis[:2000]}

请基于以上信息, 从「{self.dimension}」维度进行深度审查.
"""
        return await self.run(prompt, phase=f"{self.dimension} 审查")


async def run_parallel_reviews(
    diff_content: str,
    diff_analysis: str,
) -> dict[str, AgentResult]:
    """并行执行四个维度的审查, 最大化吞吐量和 Token 消耗."""

    reviewers = [
        ReviewerAgent("logic", LOGIC_REVIEWER_PROMPT),
        ReviewerAgent("security", SECURITY_REVIEWER_PROMPT),
        ReviewerAgent("performance", PERFORMANCE_REVIEWER_PROMPT),
        ReviewerAgent("style", STYLE_REVIEWER_PROMPT),
    ]

    tasks = [r.review(diff_content, diff_analysis) for r in reviewers]
    results = await asyncio.gather(*tasks, return_exceptions=True)

    output: dict[str, AgentResult] = {}
    for reviewer, result in zip(reviewers, results):
        if isinstance(result, Exception):
            output[reviewer.dimension] = AgentResult(
                agent_name=reviewer.name,
                content=f"审查异常: {result}",
                usage=reviewer.total_usage,
            )
        else:
            output[reviewer.dimension] = result
    return output
