"""Agent 6: 审批门 — 最终审批决策, 决定代码是否可以合并."""

from __future__ import annotations

from code_review_agents.agents.base import BaseAgent
from code_review_agents.prompts.templates import APPROVAL_GATE_PROMPT


class ApprovalGateAgent(BaseAgent):
    """VP of Engineering 角色, 做最终的合并审批.

    综合所有前置 Agent 的输出, 使用决策矩阵做出审批决定.
    安全审查员具有一票否决权.
    """

    MAX_TOKENS = 4096
    TEMPERATURE = 0.2

    def __init__(self) -> None:
        super().__init__(
            name="ApprovalGate",
            system_prompt=APPROVAL_GATE_PROMPT,
            thinking_budget=2048,
        )

    async def approve(
        self,
        diff_summary: str,
        reviews: dict[str, str],
        arbitration: str,
        fixes: str,
        tests: str,
    ) -> str:
        """做出最终审批决策."""
        prompt = f"""\
## 审查数据汇总

**变更规模**: {diff_summary[:1000]}

**逻辑审查**: {reviews.get('logic', 'N/A')[:800]}
**安全审查**: {reviews.get('security', 'N/A')[:800]}
**性能审查**: {reviews.get('performance', 'N/A')[:800]}
**规范审查**: {reviews.get('style', 'N/A')[:800]}

**仲裁决议**: {arbitration[:1000]}

**自动修复**: {fixes[:1000]}

**测试生成**: {tests[:1000]}

请做出最终审批决策 (APPROVED / CONDITIONAL / REJECTED).
"""
        result = await self.run(prompt, phase="审批决策")
        return result.content
