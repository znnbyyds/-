# 🤖 全自动代码审查与修复流水线

基于 Claude Opus 4 的 Multi-Agent 协作代码审查系统。6 个阶段、7 个专业 Agent，覆盖从 diff 解析到自动修复的完整链路。

## 架构概览

```
用户输入 PR Diff / commit
  │
  ├─ Phase 1: DiffParser Agent ─── 解析 diff → 结构化审查单元
  ├─ Phase 2: 4× Reviewer Agents (并行)
  │    ├─ LogicReviewer     逻辑正确性 (控制流/数据流/边界/业务)
  │    ├─ SecurityReviewer   安全漏洞 (OWASP/CWE/注入/认证/SSRF)
  │    ├─ PerfReviewer       性能影响 (O(n)/N+1/索引/缓存)
  │    └─ StyleReviewer      代码规范 (SRP/命名/圈复杂度/可测试性)
  ├─ Phase 3: Arbitrator Agent ─── 交叉比对 + 矛盾辩论 + 优先级排序
  ├─ Phase 4: FixGenerator Agent ─ 生成 unified diff 修复 patch
  ├─ Phase 5: TestGenerator Agent ─ 生成单元/集成/E2E 测试
  └─ Phase 6: ApprovalGate Agent ── APPROVED / CONDITIONAL / REJECTED
```

## 核心特点

| 特性 | 说明 |
|------|------|
| **多 Agent 协作** | 7 个专业 Agent, 各司其职 |
| **并行审查** | 4 个 Reviewer 并行执行, 最大化效率 |
| **辩论仲裁** | 矛盾检测 + 多轮 Agent 辩论回环 |
| **自动修复** | 根据仲裁决议生成可落地的代码 patch |
| **测试生成** | 覆盖单元/集成/E2E 的全面测试用例 |
| **高 Token 消耗** | 单次 PR 审查预估 35,000-50,000 tokens |
| **长链推理** | 每个 Agent 配备 2048-4096 token thinking budget |

## 项目结构

```
code-review-agents/
├── README.md
├── requirements.txt
├── src/code_review_agents/
│   ├── orchestrator.py            # 主编排器 (串并行混合)
│   ├── agents/
│   │   ├── base.py                # Agent 基类 (SDK 封装/重试/统计)
│   │   ├── diff_parser.py         # Agent 1: diff 解析
│   │   ├── reviewers.py           # Agent 2: 四维并行审查
│   │   ├── arbitrator.py          # Agent 3: 辩论仲裁
│   │   ├── fix_generator.py       # Agent 4: 修复生成
│   │   ├── test_generator.py      # Agent 5: 测试生成
│   │   └── approval_gate.py       # Agent 6: 审批门
│   ├── prompts/templates.py       # System Prompt 模板 (CoT)
│   └── utils/
│       ├── token_counter.py       # Token 消耗统计
│       └── formatter.py           # 报告格式化 (MD/JSON)
├── demo/
│   ├── run_demo.py                # 演示入口
│   └── sample_diff.txt            # 示例 diff (含 15 个故意埋入的问题)
└── output/                         # 生成的审查报告
```

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 设置 API Key

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

### 3. 运行演示

```bash
# 使用内置示例 diff (含 15 个故意埋入的 bug)
python demo/run_demo.py

# 使用自定义 diff
python demo/run_demo.py --diff path/to/your/pr.diff --title "修复登录模块"

# 模拟运行 (不调用 API, 展示流程和预估 token 消耗)
python demo/run_demo.py --dry-run

# 指定输出目录
python demo/run_demo.py --output ./my-reviews
```

### 4. 编程式调用

```python
import asyncio
from code_review_agents.orchestrator import CodeReviewPipeline

async def main():
    pipeline = CodeReviewPipeline(output_dir="output")
    diff = open("my_pr.diff").read()
    result = await pipeline.run(diff, pr_title="feat: add payment module")
    print(f"总 Token: {result.total_tokens:,}")

asyncio.run(main())
```

## 示例 diff 中故意埋入的问题

| # | 类型 | 描述 |
|---|------|------|
| 1 | 安全 | SQL 注入 — 字符串拼接构建查询 |
| 2 | 安全 | 密码明文比较 — 应使用 bcrypt |
| 3 | 安全 | 日志泄露敏感信息 (密码哈希) |
| 4 | 安全 | 硬编码 JWT 密钥 |
| 5 | 安全 | 用户枚举攻击 — 错误消息区分 user/密码 |
| 6 | 安全 | 认证绕过 — adminOnly 中间件逻辑错误 |
| 7 | 逻辑 | 库存检查与扣减非原子操作 → 超卖 |
| 8 | 逻辑 | 优惠券无过期校验 + 并发重复使用 |
| 9 | 逻辑 | 负数金额未处理 → 退款漏洞 |
| 10 | 逻辑 | token 黑名单未检查 |
| 11 | 性能 | N+1 查询 (循环中逐条查库存) |
| 12 | 性能 | 浮点数金额计算 (应使用整数分) |
| 13 | 规范 | 删除了 UserRepository 但直接访问 db |
| 14 | 规范 | 魔数 (税率为硬编码 0.08) |
| 15 | 规范 | 空 catch 块 + 缺少输入验证 |

## Token 消耗预估

| 阶段 | Agent | 预估 Input | 预估 Output |
|------|-------|-----------|------------|
| Phase 1 | DiffParser | 2,500 | 800 |
| Phase 2 | 4× Reviewer (并行) | 6,500 | 2,200 |
| Phase 3 | Arbitrator + 辩论 | 5,500 | 1,800 |
| Phase 4 | FixGenerator | 3,500 | 1,200 |
| Phase 5 | TestGenerator | 4,000 | 1,500 |
| Phase 6 | ApprovalGate | 1,500 | 500 |
| **总计** | **10 次 Agent 调用** | **~23,500** | **~8,000** |
| **总计** | **含 thinking buffer** | **~36,000+** | |

基于 Claude Opus 4 定价, 单次 PR 审查成本约 $0.35-$0.95。

## 许可证

MIT
