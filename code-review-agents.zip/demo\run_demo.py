#!/usr/bin/env python3
"""全自动代码审查流水线 — 演示入口.

用法:
    python demo/run_demo.py                        # 使用示例 diff
    python demo/run_demo.py --diff path/to/diff    # 使用自定义 diff
    python demo/run_demo.py --help                 # 查看帮助
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from pathlib import Path

# 添加项目根目录到 sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from code_review_agents.orchestrator import CodeReviewPipeline, console
from rich.panel import Panel
from rich.table import Table


def load_sample_diff() -> str:
    """加载示例 diff 文件."""
    sample_path = Path(__file__).parent / "sample_diff.txt"
    if not sample_path.exists():
        raise FileNotFoundError(f"示例 diff 文件不存在: {sample_path}")
    return sample_path.read_text(encoding="utf-8")


def print_banner() -> None:
    """打印启动横幅."""
    banner = """
  ╔══════════════════════════════════════════════════════════════╗
  ║   🤖 全自动代码审查与修复流水线 v1.0                       ║
  ║   Multi-Agent Code Review & Auto-Fix Pipeline              ║
  ║                                                              ║
  ║   Agent 编排: 6 阶段 × 7 专业 Agent                       ║
  ║   审查维度: 逻辑 · 安全 · 性能 · 代码规范                 ║
  ║   核心能力: 并行审查 · 辩论仲裁 · 自动修复 · 测试生成     ║
  ╚══════════════════════════════════════════════════════════════╝
    """
    console.print(banner, style="bold cyan")


def print_architecture() -> None:
    """打印流水线架构图."""
    arch = Table(title="流水线架构", show_header=False, border_style="dim")
    arch.add_column("Phase")
    arch.add_column("Agent")
    arch.add_column("模式")
    arch.add_column("Token 预估")

    phases = [
        ("Phase 1", "🔍 DiffParser", "串行", "~3,000"),
        ("Phase 2", "🔬 4× Reviewer (并行)", "并行 ×4", "~12,000"),
        ("Phase 3", "⚖️  Arbitrator (+辩论)", "串行 ×N轮", "~8,000"),
        ("Phase 4", "🔧 FixGenerator", "串行", "~5,000"),
        ("Phase 5", "🧪 TestGenerator", "串行", "~6,000"),
        ("Phase 6", "✅ ApprovalGate", "串行", "~2,000"),
    ]
    for phase, agent, mode, tokens in phases:
        arch.add_row(phase, agent, mode, tokens)

    arch.add_row("", "", "", "")
    arch.add_row("合计", "7 Agents × 6 Phases", "串并行混合", "~36,000+ tokens")

    console.print(arch)
    console.print()


async def main() -> None:
    parser = argparse.ArgumentParser(description="全自动代码审查流水线")
    parser.add_argument(
        "--diff", type=str, help="PR diff 文件路径 (默认使用内置示例)"
    )
    parser.add_argument(
        "--title", type=str, default="Sample PR: 认证 & 支付模块重构",
        help="PR 标题"
    )
    parser.add_argument(
        "--output", type=str, default="output",
        help="输出目录 (默认: output)"
    )
    parser.add_argument(
        "--api-key", type=str, default=os.getenv("ANTHROPIC_API_KEY"),
        help="Anthropic API Key (默认从环境变量读取)"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="模拟运行 (展示流程但不实际调用 API)"
    )
    args = parser.parse_args()

    print_banner()
    print_architecture()

    # 加载 diff
    if args.diff:
        diff_content = Path(args.diff).read_text(encoding="utf-8")
    else:
        diff_content = load_sample_diff()
        console.print("[dim]使用内置示例 diff (含 15 个故意埋入的问题)[/dim]\n")

    console.print(f"📝 PR 标题: [bold]{args.title}[/bold]")
    console.print(f"📊 Diff 大小: {len(diff_content)} 字符 / {len(diff_content.splitlines())} 行")
    console.print()

    if args.dry_run:
        _simulate_pipeline(diff_content, args)
        return

    # 检查 API Key
    if not args.api_key:
        console.print(
            "[yellow]⚠️  未设置 ANTHROPIC_API_KEY, 将使用模拟模式运行[/yellow]\n"
        )
        _simulate_pipeline(diff_content, args)
        return

    # 执行真实流水线
    pipeline = CodeReviewPipeline(
        output_dir=args.output,
        api_key=args.api_key,
    )

    result = await pipeline.run(diff_content, args.title)

    console.print("\n[bold green]🎉 审查完成![/bold green]")
    console.print(f"  总 Token 消耗: {result.total_tokens:,}")
    console.print(f"  报告路径: {result.report_path}")
    console.print(f"  JSON 结果: {result.json_path}")


def _simulate_pipeline(diff_content: str, args) -> None:
    """模拟执行流水线 (展示流程, 不消耗 API 调用来测试)."""
    import time
    import random

    phases = [
        ("Phase 1: DiffParser", "解析 diff 结构...", 2500, 800),
        ("Phase 2: LogicReviewer", "逻辑审查中...", 1800, 600),
        ("Phase 2: SecurityReviewer", "安全扫描中...", 2000, 700),
        ("Phase 2: PerfReviewer", "性能分析中...", 1500, 500),
        ("Phase 2: StyleReviewer", "规范检查中...", 1200, 400),
        ("Phase 3: Arbitrator", "仲裁辩论 (第1轮)...", 3000, 1000),
        ("Phase 3: Arbitrator", "仲裁辩论 (第2轮)...", 2500, 800),
        ("Phase 4: FixGenerator", "生成修复 patch...", 3500, 1200),
        ("Phase 5: TestGenerator", "生成测试用例...", 4000, 1500),
        ("Phase 6: ApprovalGate", "审批决策中...", 1500, 500),
    ]

    total_input = 0
    total_output = 0
    console.print("[bold cyan]▶ 模拟流水线执行[/bold cyan]\n")

    for phase_name, desc, est_input, est_output in phases:
        total_input += est_input
        total_output += est_output
        delay = random.uniform(0.2, 0.5)
        time.sleep(delay)
        console.print(
            f"  [green]✓[/green] {phase_name:<25s} {desc:<20s} "
            f"输入: {est_input:>5d} tok  输出: {est_output:>5d} tok"
        )

    console.print()
    total_tokens = total_input + total_output
    cost = (total_input * 15 + total_output * 75) / 1_000_000
    summary = Table(title="📊 Token 消耗汇总 (模拟)", border_style="green")
    summary.add_column("指标", style="bold")
    summary.add_column("数值", justify="right")
    summary.add_row("总输入 Token", f"{total_input:,}")
    summary.add_row("总输出 Token", f"{total_output:,}")
    summary.add_row("总 Token", f"{total_tokens:,}")
    summary.add_row("预估成本 (USD)", f"${cost:.4f}")
    summary.add_row("对话轮次", str(len(phases)))
    summary.add_row("Agent 调用次数", "10")

    console.print(summary)
    console.print(
        "\n[dim]提示: 设置 ANTHROPIC_API_KEY 环境变量以运行真实流水线[/dim]"
    )


if __name__ == "__main__":
    asyncio.run(main())
