"""Agent 3: 辩论仲裁者 — 解决审查员之间的矛盾, 生成最终问题优先级."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

from code_review_agents.agents.base import BaseAgent, AgentResult
from code_review_agents.prompts.templates import ARBITRATOR_PROMPT


@dataclass
class DebateRound:
    """一轮辩论的记录."""

    round_number: int
    topic: str
    agent_a: str
    position_a: str
    agent_b: str
    position_b: str
    resolution: str = ""
    resolved: bool = False


class ArbitratorAgent(BaseAgent):
    """辩论仲裁 Agent.

    收集四份审查报告, 进行交叉比对, 发现矛盾时触发多轮辩论循环.
    每轮辩论额外消耗大量 Token, 是 Token 消耗的主要贡献者之一.
    """

    MAX_TOKENS = 4096
    TEMPERATURE = 0.3
    MAX_DEBATE_ROUNDS: int = 3

    def __init__(self) -> None:
        super().__init__(
            name="Arbitrator",
            system_prompt=ARBITRATOR_PROMPT,
            thinking_budget=3072,
        )
        self.debate_rounds: list[DebateRound] = []

    async def arbitrate(self, reviews: dict[str, str], diff_analysis: str) -> str:
        """执行仲裁流程, 可能包含多轮辩论."""

        # 构造仲裁输入
        review_text = self._format_reviews(reviews)
        prompt = f"""\
## Diff 分析
{diff_analysis[:3000]}

## 四维审查结果
{review_text}

请开始仲裁流程: 交叉比对 → 识别矛盾 → 辩论 → 生成决议.
"""

        # 第一轮仲裁
        result = await self.run(prompt, phase="仲裁-初轮")
        arbitration_text = result.content

        # 检测是否需要额外辩论轮次
        for round_idx in range(1, self.MAX_DEBATE_ROUNDS + 1):
            contradictions = self._detect_contradictions(arbitration_text, reviews)
            if not contradictions:
                break

            debate_prompt = self._build_debate_prompt(
                arbitration_text, contradictions, round_idx
            )
            debate_result = await self.run(
                debate_prompt,
                phase=f"仲裁-辩论第{round_idx}轮",
            )
            arbitration_text = debate_result.content

        return arbitration_text

    def _format_reviews(self, reviews: dict[str, str]) -> str:
        sections = []
        labels = {
            "logic": "逻辑正确性审查",
            "security": "安全漏洞审查",
            "performance": "性能影响审查",
            "style": "代码规范审查",
        }
        for key, label in labels.items():
            content = reviews.get(key, "未提供")
            sections.append(f"### {label}\n{content[:2000]}")
        return "\n\n---\n\n".join(sections)

    def _detect_contradictions(
        self, arbitration: str, reviews: dict[str, str]
    ) -> list[dict]:
        """从仲裁文本中提取未解决的矛盾点."""
        contradictions = []
        keywords = ["矛盾", "分岐", "不一致", "contradiction", "disagree"]
        for kw in keywords:
            if kw.lower() in arbitration.lower():
                contradictions.append(
                    {"topic": "自动检测到的矛盾", "detail": "需要进一步辩论"}
                )
                break
        return contradictions

    def _build_debate_prompt(
        self,
        prev_arbitration: str,
        contradictions: list[dict],
        round_idx: int,
    ) -> str:
        return f"""\
## 第 {round_idx} 轮深度辩论

上一轮仲裁发现了以下未解决的矛盾:
{self._format_contradictions(contradictions)}

上一轮仲裁结论:
{prev_arbitration[:2000]}

请针对上述矛盾点, 逐项进行:
1. 重新审查双方的论据
2. 引用代码中的具体行作为证据
3. 如果仍然无法裁定, 明确标注为「需人工介入」
4. 给出本轮更新后的决议
"""

    def _format_contradictions(self, contradictions: list[dict]) -> str:
        return "\n".join(
            f"- **{c['topic']}**: {c.get('detail', '')}" for c in contradictions
        )
