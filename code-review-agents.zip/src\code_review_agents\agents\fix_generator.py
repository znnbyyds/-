"""Agent 4: 修复生成器 — 根据仲裁决议生成代码修复方案."""

from __future__ import annotations

from code_review_agents.agents.base import BaseAgent
from code_review_agents.prompts.templates import FIX_GENERATOR_PROMPT


class FixGeneratorAgent(BaseAgent):
    """根据仲裁结果, 为每个确认的问题生成具体的代码修复 patch."""

    MAX_TOKENS = 8192
    TEMPERATURE = 0.2

    def __init__(self) -> None:
        super().__init__(
            name="FixGenerator",
            system_prompt=FIX_GENERATOR_PROMPT,
            thinking_budget=4096,
        )

    async def generate_fixes(
        self,
        diff_content: str,
        arbitration_result: str,
    ) -> str:
        """生成修复方案."""
        prompt = f"""\
## 原始 Diff
```diff
{diff_content[:4000]}
```

## 仲裁决议 (需要修复的问题)
{arbitration_result[:4000]}

请逐个问题生成修复方案, 输出 unified diff 格式的 patch 和详细解释.
"""
        result = await self.run(prompt, phase="修复生成")
        return result.content
