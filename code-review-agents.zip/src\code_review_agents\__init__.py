"""Code Review Multi-Agent Pipeline — 全自动代码审查与修复流水线."""

__version__ = "1.0.0"
