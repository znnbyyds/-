"""Agent 基类 — 封装 Anthropic SDK 调用、token 统计与重试逻辑."""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from typing import Optional

import anthropic
from anthropic.types import Message, MessageParam


@dataclass
class TokenUsage:
    """单次 Agent 调用的 token 消耗记录."""

    agent_name: str
    phase: str
    input_tokens: int = 0
    output_tokens: int = 0
    cache_create_tokens: int = 0
    cache_read_tokens: int = 0
    duration_ms: float = 0.0
    retry_count: int = 0

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    @property
    def estimated_cost_usd(self) -> float:
        """基于 Claude Opus 4 定价估算 (input $15/M, output $75/M)."""
        return (self.input_tokens * 15 + self.output_tokens * 75) / 1_000_000


@dataclass
class AgentResult:
    """Agent 执行结果."""

    agent_name: str
    content: str
    usage: TokenUsage
    reasoning_trace: Optional[str] = None


class BaseAgent:
    """所有 Agent 的基类.

    封装 Anthropic SDK 客户端, 提供统一的调用接口、token 统计和指数退避重试.
    """

    MODEL: str = "claude-opus-4-20250514"
    MAX_TOKENS: int = 4096
    TEMPERATURE: float = 0.3
    MAX_RETRIES: int = 3

    def __init__(self, name: str, system_prompt: str, thinking_budget: int = 2048) -> None:
        self.name = name
        self.system_prompt = system_prompt
        self.thinking_budget = thinking_budget
        self._client: Optional[anthropic.AsyncAnthropic] = None
        self._total_usage = TokenUsage(agent_name=name, phase="total")

    @property
    def client(self) -> anthropic.AsyncAnthropic:
        if self._client is None:
            self._client = anthropic.AsyncAnthropic(
                api_key=os.getenv("ANTHROPIC_API_KEY", "demo-key-placeholder"),
                max_retries=2,
                timeout=120.0,
            )
        return self._client

    def _build_messages(self, user_content: str) -> list[MessageParam]:
        """构建消息列表 — 子类可覆盖以注入额外上下文."""
        return [{"role": "user", "content": user_content}]

    async def run(self, user_content: str, phase: str = "") -> AgentResult:
        """执行 Agent 调用, 含指数退避重试."""
        t0 = time.perf_counter()
        messages = self._build_messages(user_content)
        last_error = None

        for attempt in range(self.MAX_RETRIES):
            try:
                response: Message = await self.client.messages.create(
                    model=self.MODEL,
                    max_tokens=self.MAX_TOKENS,
                    temperature=self.TEMPERATURE,
                    system=self.system_prompt,
                    messages=messages,
                    thinking={
                        "type": "enabled",
                        "budget_tokens": self.thinking_budget,
                    },
                )
                usage = self._extract_usage(response, attempt)
                usage.duration_ms = (time.perf_counter() - t0) * 1000
                self._total_usage.input_tokens += usage.input_tokens
                self._total_usage.output_tokens += usage.output_tokens

                text = _extract_text(response)
                reasoning = _extract_reasoning(response)

                return AgentResult(
                    agent_name=self.name,
                    content=text,
                    usage=usage,
                    reasoning_trace=reasoning,
                )
            except (anthropic.APIStatusError, anthropic.APIConnectionError) as e:
                last_error = e
                if attempt < self.MAX_RETRIES - 1:
                    wait = 2 ** attempt
                    await asyncio.sleep(wait)
                continue

        raise RuntimeError(f"[{self.name}] 调用失败, 已重试 {self.MAX_RETRIES} 次: {last_error}")

    def _extract_usage(self, response: Message, retry_count: int) -> TokenUsage:
        return TokenUsage(
            agent_name=self.name,
            phase="",
            input_tokens=response.usage.input_tokens if response.usage else 0,
            output_tokens=response.usage.output_tokens if response.usage else 0,
            cache_create_tokens=getattr(response.usage, "cache_creation_input_tokens", 0) or 0,
            cache_read_tokens=getattr(response.usage, "cache_read_input_tokens", 0) or 0,
            retry_count=retry_count,
        )

    @property
    def total_usage(self) -> TokenUsage:
        return self._total_usage


def _extract_text(response: Message) -> str:
    for block in response.content:
        if block.type == "text":
            return block.text
    return ""


def _extract_reasoning(response: Message) -> Optional[str]:
    for block in response.content:
        if block.type == "thinking":
            return block.thinking
    return None


# ---------------------------------------------------------------------------
# 便捷工厂函数
# ---------------------------------------------------------------------------


async def run_agent_with_retry(
    agent: BaseAgent,
    prompt: str,
    phase: str = "",
) -> AgentResult:
    """带重试的单 Agent 执行."""
    return await agent.run(prompt, phase)
