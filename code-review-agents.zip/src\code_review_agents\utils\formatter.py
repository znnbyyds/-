"""报告格式化工具 — 将各 Agent 输出组装为最终审查报告."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional


def format_final_report(
    pr_title: str,
    diff_summary: str,
    reviews: dict[str, str],
    arbitration: str,
    fixes: str,
    tests: str,
    approval: str,
    token_summary: str,
) -> str:
    """组装 Markdown 格式的最终审查报告."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    report = f"""# 🔍 AI 全自动代码审查报告

**生成时间**: {now}
**PR 标题**: {pr_title}
**审查引擎**: Claude Opus 4 × 多 Agent 协作流水线

---

## 📋 1. Diff 结构分析

{diff_summary}

---

## 🔬 2. 多维度审查结果

### 2.1 逻辑正确性审查
{reviews.get('logic', '暂无')}

### 2.2 安全漏洞审查
{reviews.get('security', '暂无')}

### 2.3 性能影响审查
{reviews.get('performance', '暂无')}

### 2.4 代码规范审查
{reviews.get('style', '暂无')}

---

## ⚖️ 3. 辩论仲裁结论

{arbitration}

---

## 🔧 4. 自动修复方案

{fixes}

---

## 🧪 5. 回归测试生成

{tests}

---

## ✅ 6. 人工审批建议

{approval}

---

{token_summary}
"""
    return report


def extract_risk_level(arbitration_text: str) -> str:
    """从仲裁文本中提取风险等级."""
    text_lower = arbitration_text.lower()
    if any(w in text_lower for w in ["严重", "critical", "高危", "blocker"]):
        return "🔴 CRITICAL"
    if any(w in text_lower for w in ["高", "high", "重大", "major"]):
        return "🟠 HIGH"
    if any(w in text_lower for w in ["中", "medium", "中等", "moderate"]):
        return "🟡 MEDIUM"
    return "🟢 LOW"


def save_report(report: str, output_dir: str = "output") -> str:
    """保存报告到文件."""
    import os

    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"code_review_report_{timestamp}.md"
    path = os.path.join(output_dir, filename)
    with open(path, "w", encoding="utf-8") as f:
        f.write(report)
    return path


def save_structured_result(
    output_dir: str,
    pr_title: str,
    diff_parsed: str,
    reviews: dict[str, str],
    arbitration: str,
    fixes: str,
    tests: str,
    approval: str,
) -> str:
    """保存结构化 JSON 结果."""
    import os

    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"code_review_result_{timestamp}.json"
    path = os.path.join(output_dir, filename)
    data = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "pr_title": pr_title,
        "risk_level": extract_risk_level(arbitration),
        "diff_analysis": diff_parsed,
        "reviews": reviews,
        "arbitration": arbitration,
        "auto_fixes": fixes,
        "generated_tests": tests,
        "approval_recommendation": approval,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return path
