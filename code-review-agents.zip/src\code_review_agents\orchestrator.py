"""主编排器 — 协调 6 个 Agent 的串并行执行流水线.

流水线架构:
  Phase 1: DiffParser       (串行, 阻塞)
  Phase 2: 4× Reviewers     (并行, asyncio.gather)
  Phase 3: Arbitrator       (串行, 含辩论回环)
  Phase 4: FixGenerator     (串行)
  Phase 5: TestGenerator    (串行)
  Phase 6: ApprovalGate     (串行)
"""

from __future__ import annotations

import asyncio
import os
import time
from dataclasses import dataclass, field
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table
from rich.live import Live
from rich.layout import Layout

from code_review_agents.agents.base import TokenUsage
from code_review_agents.agents.diff_parser import DiffParserAgent
from code_review_agents.agents.reviewers import run_parallel_reviews
from code_review_agents.agents.arbitrator import ArbitratorAgent
from code_review_agents.agents.fix_generator import FixGeneratorAgent
from code_review_agents.agents.test_generator import TestGeneratorAgent
from code_review_agents.agents.approval_gate import ApprovalGateAgent
from code_review_agents.utils.token_counter import PipelineTokenReport
from code_review_agents.utils.formatter import (
    format_final_report,
    save_report,
    save_structured_result,
)

console = Console()


@dataclass
class PipelineResult:
    """流水线完整执行结果."""

    pr_title: str = ""
    diff_analysis: str = ""
    reviews: dict[str, str] = field(default_factory=dict)
    arbitration: str = ""
    fixes: str = ""
    tests: str = ""
    approval: str = ""
    token_report: Optional[PipelineTokenReport] = None
    report_path: str = ""
    json_path: str = ""
    duration_seconds: float = 0.0

    @property
    def total_tokens(self) -> int:
        if self.token_report:
            return self.token_report.total_tokens
        return 0


class CodeReviewPipeline:
    """全自动代码审查流水线编排器."""

    def __init__(
        self,
        output_dir: str = "output",
        api_key: Optional[str] = None,
        verbose: bool = True,
    ) -> None:
        self.output_dir = output_dir
        self.verbose = verbose
        self.token_report = PipelineTokenReport()
        self._init_agents()

        if api_key:
            os.environ["ANTHROPIC_API_KEY"] = api_key

    def _init_agents(self) -> None:
        """延迟初始化 Agent (在首次调用时创建, 以支持 API key 后设置)."""
        self._diff_parser: Optional[DiffParserAgent] = None
        self._arbitrator: Optional[ArbitratorAgent] = None
        self._fix_generator: Optional[FixGeneratorAgent] = None
        self._test_generator: Optional[TestGeneratorAgent] = None
        self._approval_gate: Optional[ApprovalGateAgent] = None

    async def run(self, diff_content: str, pr_title: str = "") -> PipelineResult:
        """执行完整的 6 阶段审查流水线."""
        t_start = time.perf_counter()
        result = PipelineResult(pr_title=pr_title or "Untitled PR")
        self._log_title("🚀 全自动代码审查流水线启动")

        # ---- Phase 1: Diff 解析 ----
        self._log_phase(1, "Diff 解析器 — 结构化分析")
        diff_analysis = await self._run_diff_parser(diff_content)
        result.diff_analysis = diff_analysis
        self.token_report.add_stage(
            self._diff_parser.total_usage, "Phase1-DiffParser"
        )

        # ---- Phase 2: 四维并行审查 ----
        self._log_phase(2, "四维并行审查 (逻辑/安全/性能/规范)")
        reviews = await self._run_reviewers(diff_content, diff_analysis)
        result.reviews = {k: v.content for k, v in reviews.items()}
        for key, agent_result in reviews.items():
            self.token_report.add_stage(
                agent_result.usage,
                f"Phase2-{key}Reviewer",
            )

        # ---- Phase 3: 辩论仲裁 ----
        self._log_phase(3, "辩论仲裁 — 交叉比对 + 矛盾解决")
        arbitration = await self._run_arbitrator(result.reviews, diff_analysis)
        result.arbitration = arbitration
        self.token_report.add_stage(
            self._arbitrator.total_usage, "Phase3-Arbitrator"
        )

        # ---- Phase 4: 修复生成 ----
        self._log_phase(4, "修复生成器 — 生成代码 patch")
        fixes = await self._run_fix_generator(diff_content, arbitration)
        result.fixes = fixes
        self.token_report.add_stage(
            self._fix_generator.total_usage, "Phase4-FixGen"
        )

        # ---- Phase 5: 测试生成 ----
        self._log_phase(5, "测试生成器 — 回归测试用例")
        tests = await self._run_test_generator(diff_content, fixes, diff_analysis)
        result.tests = tests
        self.token_report.add_stage(
            self._test_generator.total_usage, "Phase5-TestGen"
        )

        # ---- Phase 6: 审批决策 ----
        self._log_phase(6, "审批门 — 最终合并决策")
        approval = await self._run_approval_gate(
            diff_analysis, result.reviews, arbitration, fixes, tests
        )
        result.approval = approval
        self.token_report.add_stage(
            self._approval_gate.total_usage, "Phase6-Approval"
        )

        # ---- 最终报告 ----
        result.token_report = self.token_report
        result.duration_seconds = time.perf_counter() - t_start
        result.report_path, result.json_path = self._generate_reports(result)

        self._log_summary(result)
        return result

    # ---- 各阶段执行方法 ----

    async def _run_diff_parser(self, diff: str) -> str:
        if self._diff_parser is None:
            self._diff_parser = DiffParserAgent()
        result = await self._diff_parser.parse(diff)
        self._log_agent_result(result)
        return result

    async def _run_reviewers(
        self, diff: str, analysis: str
    ) -> dict[str, object]:
        results = await run_parallel_reviews(diff, analysis)
        for key, agent_result in results.items():
            self._log_agent_result(agent_result)
        return results

    async def _run_arbitrator(
        self, reviews: dict[str, str], analysis: str
    ) -> str:
        if self._arbitrator is None:
            self._arbitrator = ArbitratorAgent()
        content = await self._arbitrator.arbitrate(reviews, analysis)
        self._log(f"  辩论轮次: {len(self._arbitrator.debate_rounds)}")
        return content

    async def _run_fix_generator(self, diff: str, arbitration: str) -> str:
        if self._fix_generator is None:
            self._fix_generator = FixGeneratorAgent()
        return await self._fix_generator.generate_fixes(diff, arbitration)

    async def _run_test_generator(
        self, diff: str, fixes: str, analysis: str
    ) -> str:
        if self._test_generator is None:
            self._test_generator = TestGeneratorAgent()
        return await self._test_generator.generate_tests(diff, fixes, analysis)

    async def _run_approval_gate(
        self,
        summary: str,
        reviews: dict[str, str],
        arbitration: str,
        fixes: str,
        tests: str,
    ) -> str:
        if self._approval_gate is None:
            self._approval_gate = ApprovalGateAgent()
        return await self._approval_gate.approve(
            summary, reviews, arbitration, fixes, tests
        )

    def _generate_reports(self, result: PipelineResult) -> tuple[str, str]:
        token_summary = (
            self.token_report.format_summary()
            if self.token_report
            else "暂无 Token 数据"
        )

        md_report = format_final_report(
            pr_title=result.pr_title,
            diff_summary=result.diff_analysis,
            reviews=result.reviews,
            arbitration=result.arbitration,
            fixes=result.fixes,
            tests=result.tests,
            approval=result.approval,
            token_summary=token_summary,
        )

        md_path = save_report(md_report, self.output_dir)
        json_path = save_structured_result(
            self.output_dir,
            result.pr_title,
            result.diff_analysis,
            result.reviews,
            result.arbitration,
            result.fixes,
            result.tests,
            result.approval,
        )
        return md_path, json_path

    # ---- 日志输出 ----

    def _log_title(self, text: str) -> None:
        if self.verbose:
            console.print()
            console.print(Panel(text, style="bold cyan", width=70))

    def _log_phase(self, num: int, desc: str) -> None:
        if self.verbose:
            console.print(f"\n[bold yellow]━━━ Phase {num}: {desc} ━━━[/bold yellow]")

    def _log_agent_result(self, result) -> None:
        if not self.verbose:
            return
        name = getattr(result, "agent_name", "?")
        usage = getattr(result, "usage", None)
        if usage:
            console.print(
                f"  [green]✓[/green] {name:<20s} "
                f"输入: {usage.input_tokens:>5d} tok  "
                f"输出: {usage.output_tokens:>5d} tok  "
                f"耗时: {usage.duration_ms/1000:.1f}s"
            )

    def _log(self, text: str) -> None:
        if self.verbose:
            console.print(f"  [dim]{text}[/dim]")

    def _log_summary(self, result: PipelineResult) -> None:
        if not self.verbose:
            return
        console.print()
        console.print(self.token_report.format_summary())
        console.print(
            f"\n[bold green]✅ 流水线完成[/bold green] "
            f"总耗时: {result.duration_seconds:.1f}s"
        )
        console.print(f"  📄 Markdown 报告: {result.report_path}")
        console.print(f"  📊 JSON 结果:    {result.json_path}")
